<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800"><?= $title; ?></h1>

    <div class="container">
    <?php if ($this->session->flashdata('flash')) : ?>
        <div class="row mt-3">
            <div class="col-md-6">
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    Data aplikasi <strong>berhasil</strong>
                    <?= $this->session->flashdata('flash'); ?>
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
            </div>
        </div>
    <?php endif; ?>
    <div class="row mt-3">
        <div class="col-md-6">
            <a href="<?= base_url(); ?>user/tambah" class="btn btn-primary">Tambah Data Aplikasi</a>
        </div>
    </div>
    <div class="row mt-3">
        <div>
            <h3>Daftar Aplikasi</h3>
            <ul class="list-group">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th scope="col">No.</th>
                            <th scope="col" width="10%">Tanggal</th>
                            <th scope="col" width="10%">Instansi</th>
                            <th scope="col" width="15%">Nama</th>
                            <th scope="col">Email</th>
                            <th scope="col" width="20%">Aplikasi</th>
                            <th scope="col" width="25%">Detail</th>
                            <th scope="col" width="25%">Keterangan</th>
                            <th scope="col" width="25%">Paparan</th>
                            <th scope="col" width="10%">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $i = 0; ?>
                        <?php foreach ($aplikasi as $apl) : ?>
                            <?php $i++; ?>
                            <tr>
                                <th scope="row"><?= $i; ?></th>
                                <td><?= $apl['tanggal']; ?></td>
                                <td><?= $apl['instansi']; ?></td>
                                <td><?= $apl['nama']; ?></td>
                                <td><?= $apl['email']; ?></td>
                                <td><?= $apl['aplikasi']; ?></td>
                                <td><?= $apl['detail']; ?></td>
                                <td><?= $apl['keterangan']; ?></td>
                                <td><?= $apl['tgl_paparan']; ?></td>
                                <td><a href="<?= base_url(); ?>user/hapus/<?= $apl['nomor']; ?>" class="badge badge-danger" onclick="return confirm('Apakah anda yakin?');">hapus</a><a href="<?= base_url(); ?>aplikasi/edit/<?= $apl['nomor']; ?>" class="badge badge-success">edit</a></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </ul>
        </div>
    </div>

</div>
    



</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content --> 