<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800"><?= $title; ?></h1>
    <div class="container">
  <div class="row mt-3">
    <div class="col-md-6">
      <div class="card">
        <div class="card-header alert-primary">
          FROM PERMINTAAN APLIKASI
        </div>
        <form action="" method="post">
          <div class="form-group">
            <label for="tanggal">TANGGAL</label>
            <input type="date" class="form-control" name="tanggal">
            <small class="form-text text-danger"><?= form_error('tanggal'); ?></small>
          </div>
          <div class="form-group">
            <label for="opd">INSTANSI / OPD</label>
            <input type="text" class="form-control" name="opd">
            <small class="form-text text-danger"><?= form_error('opd'); ?></small>
          </div>
          <div class="form-group">
            <label for="pegawai">NAMA PEGAWAI</label>
            <input type="text" class="form-control" name="pegawai">
            <small class="form-text text-danger"><?= form_error('pegawai'); ?></small>
          </div>
          <div class="form-group">
            <label for="email">ALAMAT EMAIL</label>
            <input type="text" class="form-control" name="email">
            <small class="form-text text-danger"><?= form_error('email'); ?></small>
          </div>
          <div class="form-group">
            <label for="app">JUDUL APLIKASI</label>
            <input type="text" class="form-control" name="app">
            <small class="form-text text-danger"><?= form_error('app'); ?></small>
          </div>
          <div class="form-group">
            <label for="detApp">DETAIL APLIKASI</label>
            <textarea class="form-control" aria-label="With textarea" name="detApp"></textarea>
            <small class="form-text text-danger"><?= form_error('detApp'); ?></small>
          </div>
          <div class="form-group">
            <label for="keterangan">KETERANGAN</label>
            <textarea class="form-control" aria-label="With textarea" name="keterangan"></textarea>
            <small class="form-text text-danger"><?= form_error('keterangan'); ?></small>
          </div>
          <div class="form-group">
            <label for="verifikasi">VERIFIKASI</label>
            <select class="custom-select" name="verifikasi">
              <?php foreach ($verifikasi as $ver) : ?>
                <option value="<?= $ver; ?>"><?= $ver; ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="form-group">
            <label for="tanggalPaparan">TANGGAL PAPARAN</label>
            <input type="date" class="form-control" name="tanggalPaparan">
            <small class="form-text text-danger"><?= form_error('tanggalPaparan'); ?></small>
          </div>
          <div class="form-group">
            <label for="exampleFormControlFile1">LAMPIRAN FILE BISPRO</label>
            <input type="file" class="form-control-file" id="fileBispro">
          </div>
          <div class="form-group">
            <label for="exampleFormControlFile1">LAMPIRAN FILE SKPL</label>
            <input type="file" class="form-control-file" id="fileSkpl">
          </div>
          <div class="form-group">
            <label for="exampleFormControlFile1">LAMPIRAN FILE PAPARAN</label>
            <input type="file" class="form-control-file" id="filePaparan">
          </div>
          <button type="submit" name="tambah" class="btn btn-primary float-right">Submit</button>
        </form>
      </div>
    </div>
  </div>
<br>

    

</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content --> 