<?php
class Aplikasi_model extends CI_Model
{
    public function tampilAplikasi()
    {
        return $this->db->get('tbl_aplikasi')->result_array();
    }
    public function tambahDataApp()
    {
        $data = [
            "tanggal" => $this->input->post('tanggal', true),
            "instansi" => $this->input->post('opd', true),
            "nama" => $this->input->post('pegawai', true),
            "email" => $this->input->post('email', true),
            "aplikasi" => $this->input->post('app', true),
            "detail" => $this->input->post('detApp', true),
            "keterangan" => $this->input->post('keterangan', true),
            "verifikasi" => $this->input->post('verifikasi'),
            "file_bispro" => "NULL",
            "file_skpl" => "NULL",
            "tgl_paparan" => $this->input->post('tanggalPaparan', true),
            "file_paparan" => "NULL"
        ];
        $this->db->insert('tbl_aplikasi', $data);
    }
    public function hapusDataAplikasi($nomor)
    {
        $this->db->where('nomor', $nomor);
        $this->db->delete('tbl_aplikasi');
    }

    public function getAllAppById($nomor)
    {
        return $this->db->get_where('tbl_aplikasi', ['nomor' => $nomor])->row_array();
    }
}
